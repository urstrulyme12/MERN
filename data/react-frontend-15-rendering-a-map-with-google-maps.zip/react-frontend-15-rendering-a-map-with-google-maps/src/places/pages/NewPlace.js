import React from 'react';

const NewPlace = () => {
  return <h2>NewPlace Works!</h2>
};

export default NewPlace;